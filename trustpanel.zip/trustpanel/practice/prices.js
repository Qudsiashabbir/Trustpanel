// Retrieve the HTML elements
const priceElement = document.getElementById('price');
const getStartedButton = document.getElementById('getStarted');

// Define the price values for each submenu
const prices = {
  Submenu1: 24.99,
  Submenu2: 34.99,
  Submenu3: 49.99
};

// Function to update the price based on the selected submenu
function updatePrice(submenu) {
  priceElement.textContent = prices[submenu];
}

// Event listeners for submenu selection
document.getElementById('menu1').addEventListener('click', function() {
  updatePrice('Submenu1');
});
document.getElementById('menu2').addEventListener('click', function() {
  updatePrice('Submenu2');
});
document.getElementById('menu3').addEventListener('click', function() {
  updatePrice('Submenu3');
});

// Event listener for Get Started button
getStartedButton.addEventListener('click', function(e) {
  e.preventDefault();
  // Perform the desired action when the button is clicked
  // For example, redirect to the next page
  window.location.href = 'next_page.html';
});
