// Retrieve the form element
const checkoutForm = document.getElementById('checkoutForm');

// Event listener for form submission
checkoutForm.addEventListener('submit', function(e) {
  e.preventDefault();
  // Perform the desired action when the form is submitted
  // For example, process the payment and complete the checkout
  // You can access the entered values using cardNumber.value, expiryDate.value, cvv.value, and paymentMethod.value
  
  // Simulating payment processing
  setTimeout(function() {
    // Show the payment success popup
    showPaymentPopup();
  }, 2000);
});

// Function to show the payment success popup
function showPaymentPopup() {
  const popup = document.createElement('div');
  popup.className = 'popup';
  popup.innerHTML = `
    <div class="popup-content">
      <h2>Payment Successful!</h2>
      <p>Your payment has been successfully processed.</p>
    </div>
  `;
  document.body.appendChild(popup);

  // Remove the popup after a certain duration (e.g., 5 seconds)
  setTimeout(function() {
    document.body.removeChild(popup);
  }, 5000);
}
