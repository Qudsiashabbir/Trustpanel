// Retrieve the form element
const accountForm = document.getElementById('accountForm');

// Event listener for form submission
accountForm.addEventListener('submit', function(e) {
  e.preventDefault();
  // Perform the desired action when the form is submitted
  // For example, handle the checkout process
  // You can access the entered values using accountUrl.value and email.value
});

// Function to show the popup
function showPopup() {
  const popupContainer = document.createElement('div');
  popupContainer.classList.add('popup-container');
  popupContainer.innerHTML = `
    <div class="popup-content">
      <h2 class="popup-title">Enter Account Details</h2>
      <form id="accountForm">
        <div class="form-group">
          <label for="accountUrl">Account URL</label>
          <input type="text" id="accountUrl" class="form-control" required>
        </div>
        <div class="form-group">
          <label for="email">Email Address</label>
          <input type="email" id="email" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary">Checkout</button>
      </form>
    </div>
  `;
  document.body.appendChild(popupContainer);
}

// Call the showPopup function when the Buy Now button is clicked
document.getElementById('buyNowButton').addEventListener('click', function() {
  showPopup();
});
